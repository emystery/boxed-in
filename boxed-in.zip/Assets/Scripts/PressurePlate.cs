using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressurePlate : MonoBehaviour
{
    public GameObject[] walls;
    public GameObject[] wallsInactive;
    public GameObject[] ladders;

}
